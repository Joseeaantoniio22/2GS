﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace WpfAppEjercicio
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TxtEdad_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtEdad.Text))
            {
                return;
            }

            bool esNumero = int.TryParse(txtEdad.Text, out int edad);

            if (esNumero)
            {
                MessageBox.Show($"Edad válida: {edad} años.",
                                "Validación Correcta",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Por favor, introduce un número válido.\nNo se admiten letras ni símbolos.",
                                "Error de Formato",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);

                txtEdad.Clear();
            }
        }
    }
}