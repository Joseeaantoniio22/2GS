﻿using System.Windows;
using System.Windows.Controls;

namespace WpfAppEjercicio
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnGuardar_Click(object sender, RoutedEventArgs e)
        {
            EjecutarAccion("Guardar Datos");
        }

        private void BtnImprimir_Click(object sender, RoutedEventArgs e)
        {
            EjecutarAccion("Imprimir Reporte");
        }

        private void BtnEnviar_Click(object sender, RoutedEventArgs e)
        {
            EjecutarAccion("Enviar por Correo");
        }

        private void EjecutarAccion(string nombreAccion)
        {
            if (cmbCategorias.SelectedItem == null)
            {
                MessageBox.Show("¡Por favor, selecciona una categoría antes de continuar!",
                                "Error de Validación",
                                MessageBoxButton.OK,
                                MessageBoxImage.Warning);
                return; 
            }

            ComboBoxItem itemSeleccionado = (ComboBoxItem)cmbCategorias.SelectedItem;
            string categoria = itemSeleccionado.Content.ToString();

            string mensaje = $"Acción realizada: {nombreAccion}\n" +
                             $"Categoría afectada: {categoria}";

            MessageBox.Show(mensaje,
                            "Confirmación",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);
        }
    }
}