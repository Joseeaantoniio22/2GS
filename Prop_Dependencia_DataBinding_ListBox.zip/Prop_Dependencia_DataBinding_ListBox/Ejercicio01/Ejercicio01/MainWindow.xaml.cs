﻿using System.Windows;

namespace WpfAppEjercicio
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = this;
        }

        public static readonly DependencyProperty TamañoTextoProperty =
            DependencyProperty.Register(
                "TamañoTexto",             
                typeof(double),            
                typeof(MainWindow),         
                new PropertyMetadata(14.0)  
            );

        public double TamañoTexto
        {
            get { return (double)GetValue(TamañoTextoProperty); }
            set { SetValue(TamañoTextoProperty, value); }
        }

        private void BtnCambiarTamano_Click(object sender, RoutedEventArgs e)
        {
            TamañoTexto += 2.0;

            if (TamañoTexto > 40) TamañoTexto = 14.0;
        }
    }
}