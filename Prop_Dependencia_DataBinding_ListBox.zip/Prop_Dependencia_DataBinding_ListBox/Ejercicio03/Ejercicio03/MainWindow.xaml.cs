﻿using System.Windows;

namespace WpfAppEjercicio
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = this;
        }

        public static readonly DependencyProperty TextoUsuarioProperty =
            DependencyProperty.Register(
                "TextoUsuario",            
                typeof(string),            
                typeof(MainWindow),        
                new PropertyMetadata("Escribe algo aquí...") 
            );

        public string TextoUsuario
        {
            get { return (string)GetValue(TextoUsuarioProperty); }
            set { SetValue(TextoUsuarioProperty, value); }
        }
    }
}